export default class BaseList<T> {
  totalRecords!: number;
  records!: T;
}